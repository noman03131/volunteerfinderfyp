# Fix Navbar and Footer
# Fix Admin Issues